// UUID v4 generation for all record IDs
const { v4: uuidv4 } = require('uuid');
module.exports = { generateId: () => uuidv4() };
