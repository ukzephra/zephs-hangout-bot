// ============================================================
// Safe error handling wrappers
// Prevents crashes from Discord API errors, missing perms, etc.
// ============================================================

/**
 * Wraps an async function so unhandled errors are caught and logged
 * instead of crashing the bot.
 */
function safeExecute(fn, context = 'unknown') {
  return async (...args) => {
    try {
      return await fn(...args);
    } catch (err) {
      console.error(`[ERROR] [${context}]`, err.message || err);
      return null;
    }
  };
}

/**
 * Try to run an async operation; return { ok, data, error }
 */
async function attempt(promise, context = '') {
  try {
    const data = await promise;
    return { ok: true, data, error: null };
  } catch (error) {
    if (context) console.error(`[ERROR] [${context}]`, error.message || error);
    return { ok: false, data: null, error };
  }
}

/**
 * Safely reply to an interaction. If already replied/deferred, follow up.
 * If the interaction has expired, log and move on.
 */
async function safeReply(interaction, payload) {
  try {
    if (interaction.replied || interaction.deferred) {
      return await interaction.followUp(payload);
    }
    return await interaction.reply(payload);
  } catch (err) {
    console.error('[ERROR] [safeReply]', err.message);
    return null;
  }
}

/**
 * Safely defer an interaction reply
 */
async function safeDefer(interaction, options = {}) {
  try {
    if (!interaction.replied && !interaction.deferred) {
      return await interaction.deferReply(options);
    }
  } catch (err) {
    console.error('[ERROR] [safeDefer]', err.message);
    return null;
  }
}

module.exports = { safeExecute, attempt, safeReply, safeDefer };
