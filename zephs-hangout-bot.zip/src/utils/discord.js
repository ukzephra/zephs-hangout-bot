// ============================================================
// Discord API helper utilities
// Safe wrappers for DMs, message deletion, member fetching, etc.
// ============================================================

const { attempt } = require('./errors');

/**
 * Safely send a DM to a user. Returns { ok, data, error }.
 * Does not crash if the user has DMs disabled or has left.
 */
async function safeDM(user, payload) {
  if (!user) return { ok: false, data: null, error: 'No user provided' };
  const { ok: dmOk, data: dmChannel, error: dmErr } = await attempt(
    user.createDM(), 'safeDM:createDM'
  );
  if (!dmOk) return { ok: false, data: null, error: dmErr };

  return await attempt(dmChannel.send(payload), 'safeDM:send');
}

/**
 * Safely delete a message. Returns { ok, error }.
 */
async function safeDelete(message) {
  if (!message) return { ok: false, error: 'No message provided' };
  const { ok, error } = await attempt(message.delete(), 'safeDelete');
  if (!ok && error?.code === 10008) {
    // Message already deleted (Unknown Message)
    return { ok: true, error: null, alreadyDeleted: true };
  }
  return { ok, error };
}

/**
 * Safely fetch a message from a channel. Returns null if not found.
 */
async function safeFetchMessage(channel, messageId) {
  if (!channel || !messageId) return null;
  const { ok, data } = await attempt(
    channel.messages.fetch(messageId), 'safeFetchMessage'
  );
  return ok ? data : null;
}

/**
 * Safely fetch a guild member. Returns null if not found.
 */
async function safeFetchMember(guild, userId) {
  if (!guild || !userId) return null;
  const { ok, data } = await attempt(
    guild.members.fetch(userId), 'safeFetchMember'
  );
  return ok ? data : null;
}

/**
 * Safely fetch a channel. Returns null if not found.
 */
async function safeFetchChannel(client, channelId) {
  if (!client || !channelId) return null;
  const { ok, data } = await attempt(
    client.channels.fetch(channelId), 'safeFetchChannel'
  );
  return ok ? data : null;
}

/**
 * Safely fetch a user. Returns null if not found.
 */
async function safeFetchUser(client, userId) {
  if (!client || !userId) return null;
  const { ok, data } = await attempt(
    client.users.fetch(userId), 'safeFetchUser'
  );
  return ok ? data : null;
}

/**
 * Safely timeout a guild member.
 */
async function safeTimeout(member, durationMs, reason = '') {
  if (!member) return { ok: false, error: 'No member provided' };
  return await attempt(
    member.timeout(durationMs, reason), 'safeTimeout'
  );
}

/**
 * Safely ban a guild member.
 */
async function safeBan(guild, userId, reason = '', deleteMessageSeconds = 0) {
  if (!guild || !userId) return { ok: false, error: 'Missing guild or userId' };
  return await attempt(
    guild.members.ban(userId, { reason, deleteMessageSeconds }), 'safeBan'
  );
}

/**
 * Safely unban a user from a guild.
 */
async function safeUnban(guild, userId, reason = '') {
  if (!guild || !userId) return { ok: false, error: 'Missing guild or userId' };
  return await attempt(
    guild.members.unban(userId, reason), 'safeUnban'
  );
}

/**
 * Safely edit a message.
 */
async function safeEdit(message, payload) {
  if (!message) return { ok: false, error: 'No message provided' };
  return await attempt(message.edit(payload), 'safeEdit');
}

module.exports = {
  safeDM,
  safeDelete,
  safeFetchMessage,
  safeFetchMember,
  safeFetchChannel,
  safeFetchUser,
  safeTimeout,
  safeBan,
  safeUnban,
  safeEdit,
};
