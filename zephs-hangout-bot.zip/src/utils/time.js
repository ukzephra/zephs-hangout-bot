// ============================================================
// Time utilities — formatting, duration, Discord timestamps
// ============================================================

/**
 * Returns current UTC ISO timestamp string
 */
function now() {
  return new Date().toISOString();
}

/**
 * Returns a Date object offset from now by `ms` milliseconds
 */
function fromNow(ms) {
  return new Date(Date.now() + ms);
}

/**
 * Format a Date or ISO string as a Discord relative timestamp <t:unix:R>
 */
function discordRelative(date) {
  const unix = Math.floor(new Date(date).getTime() / 1000);
  return `<t:${unix}:R>`;
}

/**
 * Format a Date or ISO string as a Discord full date <t:unix:F>
 */
function discordFull(date) {
  const unix = Math.floor(new Date(date).getTime() / 1000);
  return `<t:${unix}:F>`;
}

/**
 * Format a Date or ISO string as a Discord short date-time <t:unix:f>
 */
function discordShort(date) {
  const unix = Math.floor(new Date(date).getTime() / 1000);
  return `<t:${unix}:f>`;
}

/**
 * Check whether an ISO timestamp has expired (is in the past)
 */
function hasExpired(isoString) {
  if (!isoString) return false;
  return new Date(isoString).getTime() <= Date.now();
}

/**
 * Milliseconds remaining until an ISO timestamp
 */
function msUntil(isoString) {
  if (!isoString) return Infinity;
  return Math.max(0, new Date(isoString).getTime() - Date.now());
}

/**
 * Format duration in ms to a human-readable string
 */
function formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days} day${days !== 1 ? 's' : ''}`;
  if (hours > 0) return `${hours} hour${hours !== 1 ? 's' : ''}`;
  if (minutes > 0) return `${minutes} minute${minutes !== 1 ? 's' : ''}`;
  return `${seconds} second${seconds !== 1 ? 's' : ''}`;
}

module.exports = {
  now,
  fromNow,
  discordRelative,
  discordFull,
  discordShort,
  hasExpired,
  msUntil,
  formatDuration,
};
