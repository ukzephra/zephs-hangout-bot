const db = require('./index');
const { now } = require('../utils/time');

function addBlockedWord(wordObj) {
  const newWord = {
    ...wordObj,
    created_at: wordObj.created_at || now()
  };
  db.tables.blocked_words.push(newWord);
  db.save();
  return newWord;
}

function removeBlockedWord(id) {
  const index = db.tables.blocked_words.findIndex(w => w.id === id);
  if (index !== -1) {
    db.tables.blocked_words.splice(index, 1);
    db.save();
    return true;
  }
  return false;
}

function removeBlockedWordByWord(word) {
  const lowerWord = word.toLowerCase();
  const index = db.tables.blocked_words.findIndex(w => w.word.toLowerCase() === lowerWord);
  if (index !== -1) {
    db.tables.blocked_words.splice(index, 1);
    db.save();
    return true;
  }
  return false;
}

function getBlockedWord(id) {
  return db.tables.blocked_words.find(w => w.id === id) || null;
}

function getBlockedWordByWord(word) {
  const lowerWord = word.toLowerCase();
  return db.tables.blocked_words.find(w => w.word.toLowerCase() === lowerWord) || null;
}

function getAllBlockedWords() {
  return [...db.tables.blocked_words];
}

function checkMessage(content) {
  if (!content) return null;
  const words = getAllBlockedWords();
  const contentLower = content.toLowerCase();
  for (const wordObj of words) {
    const wordLower = wordObj.word.toLowerCase();
    const regex = new RegExp(`\\b${escapeRegExp(wordLower)}\\b`, 'i');
    if (regex.test(contentLower)) {
      return wordObj;
    }
  }
  return null;
}

function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

module.exports = {
  addBlockedWord,
  removeBlockedWord,
  removeBlockedWordByWord,
  getBlockedWord,
  getBlockedWordByWord,
  getAllBlockedWords,
  checkMessage
};
