const db = require('./index');
const { now } = require('../utils/time');

function ensureUser(userId, username) {
  let user = db.tables.users.find(u => u.user_id === userId);
  const currentTime = now();

  if (!user) {
    user = {
      user_id: userId,
      username: username,
      standing: 'WARNING_STAGE',
      created_at: currentTime,
      updated_at: currentTime
    };
    db.tables.users.push(user);
    db.save();
  } else if (user.username !== username) {
    user.username = username;
    user.updated_at = currentTime;
    db.save();
  }
  return user;
}

function getUser(userId) {
  return db.tables.users.find(u => u.user_id === userId) || null;
}

function updateStanding(userId, standing) {
  const user = db.tables.users.find(u => u.user_id === userId);
  if (user) {
    user.standing = standing;
    user.updated_at = now();
    db.save();
    return true;
  }
  return false;
}

function getAllUsers() {
  return [...db.tables.users];
}

module.exports = {
  ensureUser,
  getUser,
  updateStanding,
  getAllUsers
};
