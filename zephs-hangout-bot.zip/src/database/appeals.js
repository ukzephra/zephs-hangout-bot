const db = require('./index');
const { now } = require('../utils/time');

function createAppeal(appeal) {
  const newAppeal = {
    ...appeal,
    status: 'PENDING',
    created_at: appeal.created_at || now()
  };
  db.tables.appeals.push(newAppeal);
  db.save();
  return newAppeal;
}

function getAppeal(id) {
  return db.tables.appeals.find(a => a.id === id) || null;
}

function getAppealByViolation(violationId) {
  return db.tables.appeals.find(a => a.violation_id === violationId) || null;
}

function getPendingAppeals() {
  return db.tables.appeals.filter(a => a.status === 'PENDING');
}

function updateAppealStatus(id, { status, reviewerId, reviewerUsername, reviewerNotes, reviewedAt }) {
  const appeal = db.tables.appeals.find(a => a.id === id);
  if (appeal) {
    if (status !== undefined) appeal.status = status;
    if (reviewerId !== undefined) appeal.reviewer_id = reviewerId;
    if (reviewerUsername !== undefined) appeal.reviewer_username = reviewerUsername;
    if (reviewerNotes !== undefined) appeal.reviewer_notes = reviewerNotes;
    if (reviewedAt !== undefined) appeal.reviewed_at = reviewedAt;
    db.save();
    return true;
  }
  return false;
}

function setReviewMessageId(id, reviewMessageId) {
  const appeal = db.tables.appeals.find(a => a.id === id);
  if (appeal) {
    appeal.review_message_id = reviewMessageId;
    db.save();
    return true;
  }
  return false;
}

function getAppealsByUser(userId) {
  return db.tables.appeals.filter(a => a.user_id === userId);
}

function hasPendingAppeal(violationId) {
  return db.tables.appeals.some(a => a.violation_id === violationId && a.status === 'PENDING');
}

module.exports = {
  createAppeal,
  getAppeal,
  getAppealByViolation,
  getPendingAppeals,
  updateAppealStatus,
  setReviewMessageId,
  getAppealsByUser,
  hasPendingAppeal
};
