const db = require('./index');
const { now } = require('../utils/time');

function createModAction(action) {
  let metadata = action.metadata;
  if (typeof metadata === 'object') {
    metadata = JSON.stringify(metadata);
  }
  const newAction = {
    ...action,
    metadata,
    created_at: action.created_at || now()
  };
  db.tables.mod_actions.push(newAction);
  db.save();
  return newAction;
}

function getModActions(targetUserId, limit = 10) {
  return db.tables.mod_actions
    .filter(a => a.target_user_id === targetUserId)
    .sort((a, b) => b.created_at - a.created_at)
    .slice(0, limit);
}

function getModActionsByReport(reportId) {
  return db.tables.mod_actions.filter(a => a.report_id === reportId);
}

function getModActionsByViolation(violationId) {
  return db.tables.mod_actions.filter(a => a.violation_id === violationId);
}

module.exports = {
  createModAction,
  getModActions,
  getModActionsByReport,
  getModActionsByViolation
};
