const db = require('./index');
const { now } = require('../utils/time');

function createViolation(violation) {
  const newViolation = {
    ...violation,
    active: 1,
    created_at: violation.created_at || now()
  };
  db.tables.violations.push(newViolation);
  db.save();
  return newViolation;
}

function getViolation(id) {
  return db.tables.violations.find(v => v.id === id) || null;
}

function getActiveViolations(userId) {
  return db.tables.violations
    .filter(v => v.user_id === userId && v.active === 1)
    .sort((a, b) => b.created_at - a.created_at);
}

function getAllViolations(userId) {
  return db.tables.violations
    .filter(v => v.user_id === userId)
    .sort((a, b) => b.created_at - a.created_at);
}

function getRecentViolations(userId, limit = 5) {
  return getAllViolations(userId).slice(0, limit);
}

function deactivateViolation(id) {
  const violation = db.tables.violations.find(v => v.id === id);
  if (violation && violation.active === 1) {
    violation.active = 0;
    db.save();
    return true;
  }
  return false;
}

function activateViolation(id) {
  const violation = db.tables.violations.find(v => v.id === id);
  if (violation && violation.active === 0) {
    violation.active = 1;
    db.save();
    return true;
  }
  return false;
}

function countActiveViolations(userId) {
  return getActiveViolations(userId).length;
}

function getViolationsByReport(reportId) {
  return db.tables.violations.filter(v => v.report_id === reportId);
}

module.exports = {
  createViolation,
  getViolation,
  getActiveViolations,
  getAllViolations,
  getRecentViolations,
  deactivateViolation,
  activateViolation,
  countActiveViolations,
  getViolationsByReport
};
