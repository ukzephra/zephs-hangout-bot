const db = require('./index');
const { now } = require('../utils/time');

function createRestriction(restriction) {
  const newRestriction = {
    ...restriction,
    active: 1,
    created_at: restriction.created_at || now()
  };
  db.tables.restrictions.push(newRestriction);
  db.save();
  return newRestriction;
}

function getRestriction(id) {
  return db.tables.restrictions.find(r => r.id === id) || null;
}

function getActiveRestrictions(userId) {
  return db.tables.restrictions.filter(r => r.user_id === userId && r.active === 1);
}

function getActiveRestrictionsByType(userId, type) {
  return db.tables.restrictions.filter(r => r.user_id === userId && r.type === type && r.active === 1);
}

function deactivateRestriction(id) {
  const restriction = db.tables.restrictions.find(r => r.id === id);
  if (restriction && restriction.active === 1) {
    restriction.active = 0;
    db.save();
    return true;
  }
  return false;
}

function deactivateRestrictionsByViolation(violationId) {
  let changed = false;
  for (const r of db.tables.restrictions) {
    if (r.violation_id === violationId && r.active === 1) {
      r.active = 0;
      changed = true;
    }
  }
  if (changed) db.save();
  return changed;
}

function getExpiredRestrictions() {
  const currentTime = now();
  return db.tables.restrictions.filter(r => r.active === 1 && r.expires_at !== null && r.expires_at <= currentTime);
}

function getAllActiveRestrictions() {
  return db.tables.restrictions.filter(r => r.active === 1);
}

module.exports = {
  createRestriction,
  getRestriction,
  getActiveRestrictions,
  getActiveRestrictionsByType,
  deactivateRestriction,
  deactivateRestrictionsByViolation,
  getExpiredRestrictions,
  getAllActiveRestrictions
};
