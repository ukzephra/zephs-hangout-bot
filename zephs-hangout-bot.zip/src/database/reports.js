const db = require('./index');
const { now } = require('../utils/time');

function createReport(report) {
  const newReport = {
    ...report,
    status: 'PENDING',
    created_at: report.created_at || now()
  };
  db.tables.reports.push(newReport);
  db.save();
  return newReport;
}

function getReport(id) {
  return db.tables.reports.find(r => r.id === id) || null;
}

function getPendingReports() {
  return db.tables.reports.filter(r => r.status === 'PENDING');
}

function updateReportStatus(id, { status, reviewerId, reviewerUsername, reviewedAt }) {
  const report = db.tables.reports.find(r => r.id === id);
  if (report) {
    if (status !== undefined) report.status = status;
    if (reviewerId !== undefined) report.reviewer_id = reviewerId;
    if (reviewerUsername !== undefined) report.reviewer_username = reviewerUsername;
    if (reviewedAt !== undefined) report.reviewed_at = reviewedAt;
    db.save();
    return true;
  }
  return false;
}

function setReviewMessageId(id, reviewMessageId) {
  const report = db.tables.reports.find(r => r.id === id);
  if (report) {
    report.review_message_id = reviewMessageId;
    db.save();
    return true;
  }
  return false;
}

function getReportsByUser(userId) {
  return db.tables.reports.filter(r => r.reported_user_id === userId);
}

module.exports = {
  createReport,
  getReport,
  getPendingReports,
  updateReportStatus,
  setReviewMessageId,
  getReportsByUser
};
