// ============================================================
// Zeph's Hangout Bot — Central Configuration
// All server-specific values, policy definitions, and settings
// ============================================================

module.exports = {
  // ── Server ──────────────────────────────────────────────
  GUILD_ID: '1533490245600018575',
  MODERATION_CHANNEL_ID: '1533490510541492288',
  RULES_CHANNEL_ID: '1533490510541492285',
  STAFF_ROLE_ID: '1534189765451190372',

  // ── Bot ─────────────────────────────────────────────────
  BOT_NAME: "Zeph's Hangout",

  // ── Policies ────────────────────────────────────────────
  POLICIES: {
    SEXUAL_CONTENT:       { id: 'SEXUAL_CONTENT',       label: 'Sexual Content' },
    BULLYING_HARASSMENT:  { id: 'BULLYING_HARASSMENT',  label: 'Bullying and Harassment' },
    EXTREME_LANGUAGE:     { id: 'EXTREME_LANGUAGE',     label: 'Extreme Language' },
    MINIMUM_AGE:          { id: 'MINIMUM_AGE',          label: 'Minimum Age Requirements' },
    ADVERTISING:          { id: 'ADVERTISING',          label: 'Advertising' },
    SPAMMING:             { id: 'SPAMMING',             label: 'Spamming' },
    MINI_MODDING:         { id: 'MINI_MODDING',         label: 'Mini-modding' },
    DISCORD_TOS:          { id: 'DISCORD_TOS',          label: 'Discord TOS Violations' },
    IMPERSONATION:        { id: 'IMPERSONATION',        label: 'Impersonation' },
    THREATS:              { id: 'THREATS',               label: 'Threats' },
  },

  // Flat array for select menus
  POLICY_CHOICES: [
    { name: 'Sexual Content',           value: 'SEXUAL_CONTENT' },
    { name: 'Bullying and Harassment',  value: 'BULLYING_HARASSMENT' },
    { name: 'Extreme Language',         value: 'EXTREME_LANGUAGE' },
    { name: 'Minimum Age Requirements', value: 'MINIMUM_AGE' },
    { name: 'Advertising',              value: 'ADVERTISING' },
    { name: 'Spamming',                 value: 'SPAMMING' },
    { name: 'Mini-modding',             value: 'MINI_MODDING' },
    { name: 'Discord TOS Violations',   value: 'DISCORD_TOS' },
    { name: 'Impersonation',            value: 'IMPERSONATION' },
    { name: 'Threats',                  value: 'THREATS' },
  ],

  // ── Standing Stages ─────────────────────────────────────
  STANDINGS: {
    WARNING_STAGE: 'WARNING_STAGE',
    LIMITED:       'LIMITED',
    VERY_LIMITED:  'VERY_LIMITED',
    AT_RISK:       'AT_RISK',
    SUSPENDED:     'SUSPENDED',
  },

  STANDING_LABELS: {
    WARNING_STAGE: 'Warning Stage',
    LIMITED:       'Limited',
    VERY_LIMITED:  'Very Limited',
    AT_RISK:       'At Risk',
    SUSPENDED:     'Suspended',
  },

  // ── Standing Thresholds ─────────────────────────────────
  // Violations needed to reach each stage (cumulative active)
  THRESHOLDS: {
    LIMITED:      3,   // 3 active violations → LIMITED
    VERY_LIMITED: 5,   // 3 + 2 more → VERY_LIMITED
    AT_RISK:      7,   // 5 + 2 more → AT_RISK
    SUSPENDED:    8,   // 7 + 1 more → SUSPENDED
  },

  // ── Punishment Durations (milliseconds) ─────────────────
  PUNISHMENTS: {
    LIMITED: {
      TIMEOUT_DURATION:      2 * 24 * 60 * 60 * 1000,  // 2 days
      IMAGE_BLOCK_DURATION:  4 * 24 * 60 * 60 * 1000,  // 4 days
    },
    VERY_LIMITED: {
      TIMEOUT_DURATION:       5 * 24 * 60 * 60 * 1000,   // 5 days
      IMAGE_BLOCK_DURATION:  21 * 24 * 60 * 60 * 1000,   // 21 days
      VOICE_BLOCK_DURATION:  21 * 24 * 60 * 60 * 1000,   // 21 days
      REACTION_BLOCK_DURATION: 21 * 24 * 60 * 60 * 1000, // 21 days
    },
  },

  // ── Detection Sources ───────────────────────────────────
  DETECTION_SOURCES: {
    HUMAN_REPORT:       'HUMAN_REPORT',
    AUTOMATED_DETECTION: 'AUTOMATED_DETECTION',
    MODERATOR_ACTION:   'MODERATOR_ACTION',
  },

  // ── Report Statuses ─────────────────────────────────────
  REPORT_STATUS: {
    PENDING:  'PENDING',
    ACCEPTED: 'ACCEPTED',
    DECLINED: 'DECLINED',
  },

  // ── Appeal Statuses ─────────────────────────────────────
  APPEAL_STATUS: {
    PENDING:  'PENDING',
    ACCEPTED: 'ACCEPTED',
    REJECTED: 'REJECTED',
  },

  // ── Restriction Types ───────────────────────────────────
  RESTRICTION_TYPES: {
    TIMEOUT:        'TIMEOUT',
    IMAGE_BLOCK:    'IMAGE_BLOCK',
    VOICE_BLOCK:    'VOICE_BLOCK',
    REACTION_BLOCK: 'REACTION_BLOCK',
  },

  // ── Mod Action Types ────────────────────────────────────
  MOD_ACTIONS: {
    REPORT_CREATED:      'REPORT_CREATED',
    REPORT_ACCEPTED:     'REPORT_ACCEPTED',
    REPORT_DECLINED:     'REPORT_DECLINED',
    MESSAGE_REMOVED:     'MESSAGE_REMOVED',
    WARNING_ISSUED:      'WARNING_ISSUED',
    STANDING_CHANGED:    'STANDING_CHANGED',
    RESTRICTION_APPLIED: 'RESTRICTION_APPLIED',
    RESTRICTION_EXPIRED: 'RESTRICTION_EXPIRED',
    USER_SUSPENDED:      'USER_SUSPENDED',
    APPEAL_SUBMITTED:    'APPEAL_SUBMITTED',
    APPEAL_ACCEPTED:     'APPEAL_ACCEPTED',
    APPEAL_REJECTED:     'APPEAL_REJECTED',
    VIOLATION_REMOVED:   'VIOLATION_REMOVED',
    AUTOMOD_ACTION:      'AUTOMOD_ACTION',
    BLOCKED_WORD_ADDED:  'BLOCKED_WORD_ADDED',
    BLOCKED_WORD_REMOVED:'BLOCKED_WORD_REMOVED',
  },

  // ── Emojis (for Components V2 DMs) ─────────────────────
  EMOJIS: {
    WARNING:      '<:30:1520357821017882675>',
    LIMITED:      '<:limited:1520356835238871132>',
    VERY_LIMITED: '<:Problemwithaccount:1520357393152741418>',
    AT_RISK:      '<:Problemwithaccount:1520357393152741418>',
    SUSPENDED:    '<:suspended:1520356881955033181>',
    APPEAL_OK:    '<:Multifactor25:1520357478645104891>',
    ACTIVE_THREADS: '<:activethreads:1520357351486656593>',
    STAFF:        '<:Staff:1520357419610411039>',
  },

  // ── Automod ─────────────────────────────────────────────
  AUTOMOD: {
    // Spam detection: max messages in time window
    SPAM_MAX_MESSAGES: 5,
    SPAM_WINDOW_MS: 5000,
    // Duplicate message threshold
    DUPLICATE_THRESHOLD: 3,
    DUPLICATE_WINDOW_MS: 30000,
  },

  // ── Health check (for UptimeRobot) ──────────────────────
  HEALTH_PORT: process.env.PORT || 3000,
};
