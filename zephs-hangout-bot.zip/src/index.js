// ============================================================
// Zeph's Hangout Bot — Entry Point
// Connects to Discord, starts health server, loads command/event
// ============================================================

require('dotenv').config();
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const express = require('express');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const { initRestrictions } = require('./moderation/restrictions');

// Ensure token is present
if (!process.env.DISCORD_BOT_TOKEN) {
  console.error('[CRITICAL] Missing DISCORD_BOT_TOKEN in environment variables!');
  process.exit(1);
}

// ── Express Health Endpoint (UptimeRobot monitoring) ────────
const app = express();
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', uptime: process.uptime() });
});

app.listen(config.HEALTH_PORT, () => {
  console.log(`[HEALTH] Server listening on port ${config.HEALTH_PORT}`);
});

// ── Discord Client Setup ─────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMembers,
  ],
});

client.commands = new Collection();

// ── Load Commands & Events ───────────────────────────────────
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js') && file !== 'deploy.js');

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  if ('data' in command && 'execute' in command) {
    client.commands.set(command.data.name, command);
  }
}

const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
  const filePath = path.join(eventsPath, file);
  const event = require(filePath);
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
}

// ── Connect to Discord ───────────────────────────────────────
client.login(process.env.DISCORD_BOT_TOKEN)
  .then(() => {
    console.log('[BOT] Discord login successful!');
    // Initialize active restriction handlers
    initRestrictions(client);
  })
  .catch(err => {
    console.error('[CRITICAL] Discord login failed:', err.message);
    process.exit(1);
  });
