// ============================================================
// Permission checking utilities
// Verifies staff role for moderation actions
// ============================================================

const config = require('../config');

/**
 * Check if a guild member has the staff role.
 */
function isStaff(member) {
  if (!member) return false;
  return member.roles.cache.has(config.STAFF_ROLE_ID);
}

/**
 * Check if an interaction user has staff permissions.
 * Works with both cached and fetched members.
 */
async function requireStaff(interaction) {
  const member = interaction.member;
  if (!member) return false;

  // If roles are cached, check directly
  if (member.roles?.cache) {
    return member.roles.cache.has(config.STAFF_ROLE_ID);
  }

  // Fetch fresh member data
  try {
    const fetched = await interaction.guild.members.fetch(interaction.user.id);
    return fetched.roles.cache.has(config.STAFF_ROLE_ID);
  } catch {
    return false;
  }
}

/**
 * Sends a permission denied ephemeral reply if user is not staff.
 * Returns true if the user IS authorized, false otherwise.
 */
async function checkStaffOrDeny(interaction) {
  const authorized = await requireStaff(interaction);
  if (!authorized) {
    try {
      const payload = {
        content: '❌ You do not have permission to perform this action.',
        ephemeral: true,
      };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(payload);
      } else {
        await interaction.reply(payload);
      }
    } catch (err) {
      console.error('[PERM] Failed to send denial:', err.message);
    }
    return false;
  }
  return true;
}

module.exports = { isStaff, requireStaff, checkStaffOrDeny };
