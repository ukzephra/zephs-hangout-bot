const { time } = require('discord.js');

function buildReportMessage(report) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: `**Report ID:** ${report.id}\n**Reporter:** <@${report.reporter_id}> (${report.reporter_username})\n**Reported User:** <@${report.reported_user_id}> (${report.reported_username})\n**Reason:** ${report.reason}\n**Channel:** <#${report.channel_id}>\n**Message Preview:** ${report.message_content || 'N/A'}\n**Policy:** ${report.policy}\n**Source:** ${report.detection_source}\n**Time:** <t:${Math.floor(new Date(report.created_at).getTime() / 1000)}:f>`
                    },
                    { type: 14, spacing: 2 },
                    {
                        type: 1,
                        components: [
                            { style: 3, type: 2, custom_id: `report:accept:${report.id}`, label: "Accept" },
                            { style: 4, type: 2, custom_id: `report:decline:${report.id}`, label: "Decline" }
                        ]
                    }
                ]
            }
        ]
    };
}

function buildAutomodReportMessage(report, autoAction, details) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: `**Automod Alert Report ID:** ${report.id}\n**Reported User:** <@${report.reported_user_id}> (${report.reported_username})\n**Automod Action Taken:** ${autoAction}\n**Details:** ${details}\n**Channel:** <#${report.channel_id}>\n**Message Preview:** ${report.message_content || 'N/A'}\n**Policy:** ${report.policy}\n**Source:** ${report.detection_source}\n**Time:** <t:${Math.floor(new Date(report.created_at).getTime() / 1000)}:f>`
                    },
                    { type: 14, spacing: 2 },
                    {
                        type: 1,
                        components: [
                            { style: 3, type: 2, custom_id: `report:accept:${report.id}`, label: "Accept" },
                            { style: 4, type: 2, custom_id: `report:decline:${report.id}`, label: "Decline" },
                            { style: 1, type: 2, custom_id: `automod:reverse:${report.id}`, label: "Reverse Action" }
                        ]
                    }
                ]
            }
        ]
    };
}

function buildResolvedReportMessage(report, reviewer, action) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: `**Report ID:** ${report.id}\n**Reported User:** <@${report.reported_user_id}> (${report.reported_username})\n**Status:** Resolved by <@${reviewer.id}> (${reviewer.username})\n**Action Taken:** ${action}`
                    },
                    { type: 14, spacing: 2 },
                    {
                        type: 1,
                        components: [
                            { style: 2, type: 2, custom_id: `resolved_${report.id}`, label: "Resolved", disabled: true }
                        ]
                    }
                ]
            }
        ]
    };
}

function buildDeclinedReportMessage(report, reviewer) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: `**Report ID:** ${report.id}\n**Reported User:** <@${report.reported_user_id}> (${report.reported_username})\n**Status:** Declined by <@${reviewer.id}> (${reviewer.username})`
                    },
                    { type: 14, spacing: 2 },
                    {
                        type: 1,
                        components: [
                            { style: 2, type: 2, custom_id: `declined_${report.id}`, label: "Declined", disabled: true }
                        ]
                    }
                ]
            }
        ]
    };
}

module.exports = {
    buildReportMessage,
    buildAutomodReportMessage,
    buildResolvedReportMessage,
    buildDeclinedReportMessage
};
