function buildAppealMessage(appeal, violation) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: `**Appeal ID:** ${appeal.id}\n**User:** <@${appeal.user_id}>\n**Policy Violated:** ${violation.policy}\n**Original Violation Date:** <t:${Math.floor(new Date(violation.created_at).getTime() / 1000)}:f>\n**Violation Reason:** ${violation.reason}\n\n**Appeal Reason provided by user:**\n${appeal.reason}`
                    },
                    { type: 14, spacing: 2 },
                    {
                        type: 1,
                        components: [
                            { style: 3, type: 2, custom_id: `appeal:accept:${appeal.id}`, label: "Accept Appeal" },
                            { style: 4, type: 2, custom_id: `appeal:reject:${appeal.id}`, label: "Reject Appeal" }
                        ]
                    }
                ]
            }
        ]
    };
}

function buildResolvedAppealMessage(appeal, reviewer, decision) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: `**Appeal ID:** ${appeal.id}\n**User:** <@${appeal.user_id}>\n**Status:** Reviewed by <@${reviewer.id}> (${reviewer.username})\n**Decision:** ${decision}`
                    },
                    { type: 14, spacing: 2 },
                    {
                        type: 1,
                        components: [
                            { style: 2, type: 2, custom_id: `resolved_${appeal.id}`, label: decision, disabled: true }
                        ]
                    }
                ]
            }
        ]
    };
}

module.exports = {
    buildAppealMessage,
    buildResolvedAppealMessage
};
