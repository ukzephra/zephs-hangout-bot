const { STANDINGS } = require('../config');

function buildWarningDM(violationId) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: "## <:30:1520357821017882675> You broke our server rules\nWe've taken action that affects your presence in our server."
                    },
                    {
                        type: 1,
                        components: [
                            { style: 2, type: 2, custom_id: `violation:learn_more:${violationId}`, label: "Learn more" },
                            { style: 2, type: 2, custom_id: `violation:appeal:${violationId}`, label: "Appeal this violation" }
                        ]
                    }
                ]
            }
        ]
    };
}

function buildLimitedDM(violationId) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: "## <:limited:1520356835238871132> You broke our server rules\nWe've taken action that affects your presence in our server."
                    },
                    {
                        type: 1,
                        components: [
                            { style: 2, type: 2, custom_id: `violation:learn_more:${violationId}`, label: "Learn more" },
                            { style: 2, type: 2, custom_id: `violation:appeal:${violationId}`, label: "Appeal this violation" }
                        ]
                    }
                ]
            }
        ]
    };
}

function buildVeryLimitedDM(violationId) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: "## <:Problemwithaccount:1520357393152741418> You broke our server rules\nWe've taken action that affects your presence in our server."
                    },
                    { type: 14, spacing: 2 },
                    {
                        type: 1,
                        components: [
                            { style: 2, type: 2, custom_id: `violation:learn_more:${violationId}`, label: "Learn more" },
                            { style: 2, type: 2, custom_id: `violation:appeal:${violationId}`, label: "Appeal this violation" }
                        ]
                    }
                ]
            }
        ]
    };
}

function buildAtRiskDM(violationId) {
    return buildVeryLimitedDM(violationId);
}

function buildSuspendedDM(violationId) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: "## <:suspended:1520356881955033181> You broke our server rules\nWe've taken action that affects your presence in our server."
                    },
                    {
                        type: 1,
                        components: [
                            { style: 2, type: 2, custom_id: `violation:learn_more:${violationId}`, label: "Learn more" },
                            { style: 2, type: 2, custom_id: `violation:appeal:${violationId}`, label: "Appeal this violation" }
                        ]
                    }
                ]
            }
        ]
    };
}

function getDMForStanding(standing, violationId) {
    switch (standing) {
        case 'WARNING_STAGE':
            return buildWarningDM(violationId);
        case 'LIMITED':
            return buildLimitedDM(violationId);
        case 'VERY_LIMITED':
            return buildVeryLimitedDM(violationId);
        case 'AT_RISK':
            return buildAtRiskDM(violationId);
        case 'SUSPENDED':
            return buildSuspendedDM(violationId);
        default:
            return buildWarningDM(violationId);
    }
}

function buildAppealAcceptedDM(policyLabel) {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: `## <:Multifactor25:1520357478645104891> We have removed a violation from your account\nWe've reviewed a violation on your account regarding our ${policyLabel} policy. We've determined that this does not violate the policy and therefore, we have removed the violation from your account.`
                    }
                ]
            }
        ]
    };
}

function buildAppealRejectedDM() {
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: [
                    {
                        type: 10,
                        content: "## Appeal Rejected\nAfter careful review, we have decided not to remove the violation from your account."
                    }
                ]
            }
        ]
    };
}

module.exports = {
    buildWarningDM,
    buildLimitedDM,
    buildVeryLimitedDM,
    buildAtRiskDM,
    buildSuspendedDM,
    getDMForStanding,
    buildAppealAcceptedDM,
    buildAppealRejectedDM
};
