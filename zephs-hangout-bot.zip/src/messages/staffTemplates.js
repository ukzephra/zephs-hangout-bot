function buildStaffMessage({ subject, content, author, timestamp, includeForm, formButtonId }) {
    const authorName = author || 'SYSTEM';
    
    const components = [
        {
            type: 10,
            content: `-# <:activethreads:1520357351486656593> Subject: ${subject}`
        },
        { type: 14 },
        {
            type: 10,
            content: content
        },
        { type: 14 },
        {
            type: 10,
            content: `-# Sent by ${authorName} <:Staff:1520357419610411039> at ${timestamp}`
        }
    ];
    
    if (includeForm && formButtonId) {
        components.push({
            type: 1,
            components: [
                { style: 2, type: 2, custom_id: `staffmsg:form:${formButtonId}`, label: "Open Form" }
            ]
        });
    }
    
    return {
        flags: 32768,
        components: [
            {
                type: 17,
                components: components
            }
        ]
    };
}

module.exports = {
    buildStaffMessage
};
