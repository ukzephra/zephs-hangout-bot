const db = require('../database/index.js');
const ids = require('../utils/ids.js');
const timeUtils = require('../utils/time.js');

function logModAction(actionData) {
    const {
        action,
        target_user_id,
        moderator_id,
        policy = null,
        reason = null,
        previous_standing = null,
        new_standing = null,
        punishment = null,
        report_id = null,
        violation_id = null,
        appeal_id = null,
        metadata = {}
    } = actionData;

    try {
        db.prepare(`
            INSERT INTO mod_actions (id, action, target_user_id, moderator_id, policy, reason, previous_standing, new_standing, punishment, report_id, violation_id, appeal_id, metadata, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            ids.generateId(), action, target_user_id, moderator_id, policy, reason, previous_standing, new_standing, punishment, report_id, violation_id, appeal_id, JSON.stringify(metadata), timeUtils.now()
        );
        console.log(`[MOD LOG] ${action} on ${target_user_id} by ${moderator_id}`);
    } catch (err) {
        console.error('Failed to log mod action:', err);
    }
}

module.exports = { logModAction };
