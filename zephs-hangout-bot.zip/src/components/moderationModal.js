const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags } = require('discord.js');
const db = require('../database/index.js');
const { generateId } = require('../utils/ids.js');
const { now } = require('../utils/time.js');
const { safeDM, safeDelete, safeTimeout, safeBan } = require('../utils/discord.js');
const config = require('../config.js');

async function showModerationModal(interaction, reportId) {
  const modal = new ModalBuilder()
    .setCustomId(`mod_submit:${reportId}`)
    .setTitle('Accept Report & Sanction');

  const policyInput = new TextInputBuilder()
    .setCustomId('policy')
    .setLabel('Policy Violation (e.g. HARASSMENT)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const reasonInput = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('Reason sent to user')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const notesInput = new TextInputBuilder()
    .setCustomId('notes')
    .setLabel('Internal Notes (Optional)')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false);

  const sanctionsInput = new TextInputBuilder()
    .setCustomId('sanctions')
    .setLabel('Additional Sanctions (e.g. Ban/Days)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(policyInput),
    new ActionRowBuilder().addComponents(reasonInput),
    new ActionRowBuilder().addComponents(notesInput),
    new ActionRowBuilder().addComponents(sanctionsInput)
  );

  await interaction.showModal(modal);
}

async function handleModerationModalSubmit(interaction) {
  const parts = interaction.customId.split(':');
  const reportId = parts[1];

  const policy = interaction.fields.getTextInputValue('policy');
  const reason = interaction.fields.getTextInputValue('reason');
  const notes = interaction.fields.getTextInputValue('notes') || null;
  const sanctions = interaction.fields.getTextInputValue('sanctions') || null;

  const report = db.prepare('SELECT * FROM reports WHERE id = ?').get(reportId);
  if (!report) {
    return interaction.reply({ content: 'Report not found in database.', ephemeral: true });
  }

  // Mark report as accepted
  db.prepare(`
    UPDATE reports
    SET status = ?, reviewer_id = ?, reviewer_username = ?, reviewed_at = ?
    WHERE id = ?
  `).run('ACCEPTED', interaction.user.id, interaction.user.username, now(), reportId);

  // Deactivate/remove message if possible
  if (report.channel_id && report.message_id) {
    await safeDelete(interaction.client, report.channel_id, report.message_id);
  }

  // Create violation record
  const violationId = generateId();
  db.prepare(`
    INSERT INTO violations (
      id, user_id, policy, moderator_id, moderator_username, detection_source,
      message_id, channel_id, message_content, report_id, reason, internal_notes, punishment, active, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    violationId, report.reported_user_id, policy, interaction.user.id, interaction.user.username,
    report.detection_source || 'HUMAN_REPORT', report.message_id, report.channel_id, report.message_content,
    reportId, reason, notes, sanctions, 1, now()
  );

  // Recalculate standing
  const activeViolationsCount = db.prepare('SELECT COUNT(*) as count FROM violations WHERE user_id = ? AND active = 1').get(report.reported_user_id).count;
  
  let newStanding = 'WARNING_STAGE';
  if (activeViolationsCount >= config.THRESHOLDS.SUSPENDED) newStanding = 'SUSPENDED';
  else if (activeViolationsCount >= config.THRESHOLDS.AT_RISK) newStanding = 'AT_RISK';
  else if (activeViolationsCount >= config.THRESHOLDS.VERY_LIMITED) newStanding = 'VERY_LIMITED';
  else if (activeViolationsCount >= config.THRESHOLDS.LIMITED) newStanding = 'LIMITED';

  // Make sure user exists in db
  db.prepare(`
    INSERT INTO users (user_id, username, standing, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(user_id) DO UPDATE SET standing = excluded.standing, updated_at = excluded.updated_at
  `).run(report.reported_user_id, report.reported_username || 'Unknown', newStanding, now(), now());

  // Apply punishments
  if (newStanding === 'SUSPENDED') {
    await safeBan(interaction.guild, report.reported_user_id, 'Accumulated too many violations.');
  } else if (newStanding === 'VERY_LIMITED') {
    await safeTimeout(interaction.guild, report.reported_user_id, 5 * 24 * 60 * 60 * 1000, 'Reached VERY_LIMITED standing');
  } else if (newStanding === 'LIMITED') {
    await safeTimeout(interaction.guild, report.reported_user_id, 2 * 24 * 60 * 60 * 1000, 'Reached LIMITED standing');
  }

  // Send DM (V2)
  const dmContent = [
    { type: 17, components: [
      { type: 10, content: \`Your account received a violation for **\${policy}**.\` },
      { type: 10, content: \`Reason: \${reason}\` },
      { type: 10, content: \`Current Standing: \${config.STANDING_LABELS?.[newStanding] || newStanding}\` }
    ]},
    { type: 1, components: [
      { type: 2, style: 2, label: 'Learn More', custom_id: \`violation:learn_more:\${violationId}\` },
      { type: 2, style: 2, label: 'Appeal', custom_id: \`violation:appeal:\${violationId}\` }
    ]}
  ];

  await safeDM(interaction.client, report.reported_user_id, {
    flags: MessageFlags.IsComponentsV2,
    components: dmContent
  });

  // Log action
  db.prepare(`
    INSERT INTO mod_actions (id, action, target_user_id, moderator_id, policy, reason, new_standing, report_id, violation_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(generateId(), 'VIOLATION_ISSUED', report.reported_user_id, interaction.user.id, policy, reason, newStanding, reportId, violationId, now());

  await interaction.update({
    content: \`*Report accepted by \${interaction.user.username}. Violation issued.*\`,
    components: []
  });
}

module.exports = {
  showModerationModal,
  handleModerationModalSubmit
};
