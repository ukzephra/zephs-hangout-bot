const { checkStaffOrDeny } = require('../permissions/index.js');
const db = require('../database/index.js');
const { now } = require('../utils/time.js');
const { generateId } = require('../utils/ids.js');
const config = require('../config.js');

async function handleAutomodReverse(interaction, reportId) {
  if (!checkStaffOrDeny(interaction)) return;

  const report = db.prepare('SELECT * FROM reports WHERE id = ?').get(reportId);
  if (!report) {
    return interaction.reply({ content: 'Report not found.', ephemeral: true });
  }

  const violation = db.prepare('SELECT * FROM violations WHERE report_id = ?').get(reportId);
  if (!violation) {
    return interaction.reply({ content: 'Associated violation not found.', ephemeral: true });
  }

  // 2. Mark violation inactive
  db.prepare('UPDATE violations SET active = 0 WHERE id = ?').run(violation.id);
  db.prepare('UPDATE restrictions SET active = 0 WHERE violation_id = ?').run(violation.id);

  // 3. Recalculate standing
  const activeViolationsCount = db.prepare('SELECT COUNT(*) as count FROM violations WHERE user_id = ? AND active = 1').get(violation.user_id).count;
  let newStanding = 'WARNING_STAGE';
  if (activeViolationsCount >= config.THRESHOLDS.SUSPENDED) newStanding = 'SUSPENDED';
  else if (activeViolationsCount >= config.THRESHOLDS.AT_RISK) newStanding = 'AT_RISK';
  else if (activeViolationsCount >= config.THRESHOLDS.VERY_LIMITED) newStanding = 'VERY_LIMITED';
  else if (activeViolationsCount >= config.THRESHOLDS.LIMITED) newStanding = 'LIMITED';

  db.prepare('UPDATE users SET standing = ?, updated_at = ? WHERE user_id = ?').run(newStanding, now(), violation.user_id);

  // 4. Send confirmation update message
  await interaction.reply({ content: 'Action reversed and standing recalculated.', ephemeral: true });

  // 5. Edit message
  await interaction.message.edit({
    content: `*Automod action reversed by ${interaction.user.username}*`,
    components: []
  });

  // Log action
  db.prepare(`
    INSERT INTO mod_actions (id, action, target_user_id, moderator_id, report_id, violation_id, new_standing, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(generateId(), 'AUTOMOD_REVERSED', violation.user_id, interaction.user.id, reportId, violation.id, newStanding, now());
}

module.exports = {
  handleAutomodReverse
};
