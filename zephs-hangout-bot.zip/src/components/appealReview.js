const { checkStaffOrDeny } = require('../permissions/index.js');
const db = require('../database/index.js');
const { now } = require('../utils/time.js');
const { safeDM } = require('../utils/discord.js');
const { generateId } = require('../utils/ids.js');
const config = require('../config.js');
const { MessageFlags } = require('discord.js');

async function handleAppealInteraction(interaction) {
  if (!checkStaffOrDeny(interaction)) return;

  const parts = interaction.customId.split(':');
  const action = parts[1];
  const appealId = parts[2];

  const appeal = db.prepare('SELECT * FROM appeals WHERE id = ?').get(appealId);
  if (!appeal) {
    return interaction.reply({ content: 'Appeal not found.', ephemeral: true });
  }

  if (action === 'accept') {
    // 1. Mark violation as inactive
    db.prepare('UPDATE violations SET active = 0 WHERE id = ?').run(appeal.violation_id);

    // 2. Mark appeal as accepted
    db.prepare(`
      UPDATE appeals
      SET status = 'ACCEPTED', reviewer_id = ?, reviewer_username = ?, reviewed_at = ?
      WHERE id = ?
    `).run(interaction.user.id, interaction.user.username, now(), appealId);

    // 3. Remove restrictions (if any recorded in db)
    db.prepare('UPDATE restrictions SET active = 0 WHERE violation_id = ?').run(appeal.violation_id);

    // 4. Recalculate standing
    const activeViolationsCount = db.prepare('SELECT COUNT(*) as count FROM violations WHERE user_id = ? AND active = 1').get(appeal.user_id).count;
    let newStanding = 'WARNING_STAGE';
    if (activeViolationsCount >= config.THRESHOLDS.SUSPENDED) newStanding = 'SUSPENDED';
    else if (activeViolationsCount >= config.THRESHOLDS.AT_RISK) newStanding = 'AT_RISK';
    else if (activeViolationsCount >= config.THRESHOLDS.VERY_LIMITED) newStanding = 'VERY_LIMITED';
    else if (activeViolationsCount >= config.THRESHOLDS.LIMITED) newStanding = 'LIMITED';

    db.prepare('UPDATE users SET standing = ?, updated_at = ? WHERE user_id = ?').run(newStanding, now(), appeal.user_id);

    // 5. Send Appeal Accepted DM (V2)
    const dmComponents = [
      { type: 17, components: [
        { type: 10, content: `Your appeal for **${appeal.policy}** has been accepted.` },
        { type: 10, content: `The violation has been removed from your record.` },
        { type: 10, content: `Current Standing: ${config.STANDING_LABELS?.[newStanding] || newStanding}` }
      ]}
    ];
    await safeDM(interaction.client, appeal.user_id, {
      flags: MessageFlags.IsComponentsV2,
      components: dmComponents
    });

    // 6. Edit appeal review message
    await interaction.update({
      content: `*Appeal accepted by ${interaction.user.username}*`,
      components: []
    });

    // 7. Log action
    db.prepare(`
      INSERT INTO mod_actions (id, action, target_user_id, moderator_id, policy, new_standing, appeal_id, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(generateId(), 'APPEAL_ACCEPTED', appeal.user_id, interaction.user.id, appeal.policy, newStanding, appealId, now());

  } else if (action === 'reject') {
    // 1. Mark appeal as rejected
    db.prepare(`
      UPDATE appeals
      SET status = 'REJECTED', reviewer_id = ?, reviewer_username = ?, reviewed_at = ?
      WHERE id = ?
    `).run(interaction.user.id, interaction.user.username, now(), appealId);

    // 2. Edit appeal review message
    await interaction.update({
      content: `*Appeal rejected by ${interaction.user.username}*`,
      components: []
    });

    // 3. Log action
    db.prepare(`
      INSERT INTO mod_actions (id, action, target_user_id, moderator_id, appeal_id, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(generateId(), 'APPEAL_REJECTED', appeal.user_id, interaction.user.id, appealId, now());
  }
}

module.exports = {
  handleAppealInteraction
};
