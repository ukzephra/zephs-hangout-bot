const db = require('../database/index.js');
const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

async function handleLearnMore(interaction, violationId) {
  const violation = db.prepare('SELECT * FROM violations WHERE id = ?').get(violationId);
  
  if (!violation) {
    return interaction.reply({ content: 'Details for this violation could not be found.', ephemeral: true });
  }

  const restrictions = db.prepare('SELECT * FROM restrictions WHERE violation_id = ? AND active = 1').all(violationId);
  let restrictionText = restrictions.length > 0 ? restrictions.map(r => `- ${r.type} (Expires: <t:${Math.floor(r.expires_at / 1000)}:R>)`).join('\n') : 'None';

  const modal = new ModalBuilder()
    .setCustomId(`violation_info:${violationId}`)
    .setTitle('Violation Details');

  const infoDisplay = new TextInputBuilder()
    .setCustomId('info_display')
    .setLabel('Information')
    .setStyle(TextInputStyle.Paragraph)
    .setValue(`Policy: ${violation.policy}\nReason: ${violation.reason}\nDetection: ${violation.detection_source}\nRestrictions: ${restrictionText}`)
    .setRequired(false);

  modal.addComponents(new ActionRowBuilder().addComponents(infoDisplay));

  await interaction.showModal(modal);
}

module.exports = {
  handleLearnMore
};
