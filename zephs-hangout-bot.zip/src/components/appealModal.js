const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags } = require('discord.js');
const db = require('../database/index.js');
const { generateId } = require('../utils/ids.js');
const { now } = require('../utils/time.js');
const config = require('../config.js');

async function showAppealModal(interaction, violationId) {
  const modal = new ModalBuilder()
    .setCustomId(`appeal_submit:${violationId}`)
    .setTitle('Appeal Violation');

  const reasonInput = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('Why was this violation incorrect?')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(1000);

  modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));
  
  await interaction.showModal(modal);
}

async function handleAppealSubmit(interaction) {
  const parts = interaction.customId.split(':');
  const violationId = parts[1];
  const reason = interaction.fields.getTextInputValue('reason');

  const violation = db.prepare('SELECT * FROM violations WHERE id = ?').get(violationId);
  if (!violation) {
    return interaction.reply({ content: 'Violation not found.', ephemeral: true });
  }

  const appealId = generateId();
  db.prepare(`
    INSERT INTO appeals (id, user_id, violation_id, policy, reason, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(appealId, interaction.user.id, violationId, violation.policy, reason, 'PENDING', now());

  // Post to mod channel (V2)
  const modChannel = interaction.guild.channels.cache.get(config.MODERATION_CHANNEL_ID);
  if (modChannel) {
    const components = [
      { type: 17, components: [
        { type: 10, content: `**Appeal Submitted**` },
        { type: 10, content: `User: <@${interaction.user.id}> (${interaction.user.tag})` },
        { type: 10, content: `Policy: ${violation.policy}` },
        { type: 10, content: `Reason: ${reason}` }
      ]},
      { type: 1, components: [
        { type: 2, style: 3, label: 'Accept Appeal', custom_id: `appeal:accept:${appealId}` },
        { type: 2, style: 4, label: 'Reject Appeal', custom_id: `appeal:reject:${appealId}` }
      ]}
    ];

    const appealMessage = await modChannel.send({
      flags: MessageFlags.IsComponentsV2,
      components
    });

    db.prepare('UPDATE appeals SET review_message_id = ? WHERE id = ?').run(appealMessage.id, appealId);
  }

  await interaction.reply({
    content: 'Your appeal has been submitted and will be reviewed by our moderation team.',
    ephemeral: true
  });
}

module.exports = {
  showAppealModal,
  handleAppealSubmit
};
