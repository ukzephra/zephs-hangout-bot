const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

function buildReportModal(targetId, targetType, messageId = null, channelId = null) {
  const modal = new ModalBuilder()
    .setCustomId(`report_submit:${targetType}:${targetId}:${messageId || 'none'}:${channelId || 'none'}`)
    .setTitle('Report to Moderators');

  const reasonInput = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('Reason for report')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(1000);

  const policyInput = new TextInputBuilder()
    .setCustomId('policy')
    .setLabel('Which rule was broken? (e.g., SPAM)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(100);

  const additionalInfoInput = new TextInputBuilder()
    .setCustomId('additional_info')
    .setLabel('Additional Information')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(1000);

  const firstActionRow = new ActionRowBuilder().addComponents(reasonInput);
  const secondActionRow = new ActionRowBuilder().addComponents(policyInput);
  const thirdActionRow = new ActionRowBuilder().addComponents(additionalInfoInput);

  modal.addComponents(firstActionRow, secondActionRow, thirdActionRow);

  return modal;
}

module.exports = {
  buildReportModal
};
