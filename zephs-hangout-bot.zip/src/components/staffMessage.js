const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

async function handleStaffMessageInteraction(interaction) {
  const parts = interaction.customId.split(':');
  
  if (parts[1] === 'form') {
    const messageId = parts[2];
    
    const modal = new ModalBuilder()
      .setCustomId(`staff_form_submit:${messageId}`)
      .setTitle('Staff Form');
      
    const feedbackInput = new TextInputBuilder()
      .setCustomId('feedback')
      .setLabel('Your Feedback/Input')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
      
    modal.addComponents(new ActionRowBuilder().addComponents(feedbackInput));
    
    await interaction.showModal(modal);
  }
}

module.exports = {
  handleStaffMessageInteraction
};
