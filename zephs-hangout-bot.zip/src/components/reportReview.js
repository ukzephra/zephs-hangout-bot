const { checkStaffOrDeny } = require('../permissions/index.js');
const db = require('../database/index.js');
const { now } = require('../utils/time.js');
const { showModerationModal } = require('./moderationModal.js');
const { generateId } = require('../utils/ids.js');

async function handleReportInteraction(interaction) {
  if (!checkStaffOrDeny(interaction)) return;

  const customId = interaction.customId;
  const parts = customId.split(':');
  
  if (parts[1] === 'accept') {
    const reportId = parts[2];
    await showModerationModal(interaction, reportId);
  } else if (parts[1] === 'decline') {
    const reportId = parts[2];
    
    // Mark report as declined
    db.prepare(`
      UPDATE reports
      SET status = ?, reviewer_id = ?, reviewer_username = ?, reviewed_at = ?
      WHERE id = ?
    `).run('DECLINED', interaction.user.id, interaction.user.username, now(), reportId);

    // Update message
    await interaction.update({
      content: `*Report declined by ${interaction.user.username}*`,
      components: []
    });

    // Log action
    db.prepare(`
      INSERT INTO mod_actions (id, action, moderator_id, report_id, created_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(generateId(), 'REPORT_DECLINED', interaction.user.id, reportId, now());
  }
}

module.exports = {
  handleReportInteraction
};
