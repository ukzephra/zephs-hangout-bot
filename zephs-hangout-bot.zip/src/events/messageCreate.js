const db = require('../database/index.js');
const config = require('../config.js');
const discordUtils = require('../utils/discord.js');
const timeUtils = require('../utils/time.js');
const ids = require('../utils/ids.js');

module.exports = {
    name: 'messageCreate',
    async execute(message) {
        if (message.author.bot) return;
        if (!message.guild) return;

        const userId = message.author.id;
        const now = timeUtils.now();

        // 1. Enforce Image Block
        if (message.attachments.size > 0) {
            const hasImageBlock = db.prepare('SELECT id FROM restrictions WHERE user_id = ? AND type = ? AND active = 1 AND expires_at > ?')
                .get(userId, config.RESTRICTION_TYPES.IMAGE_BLOCK, now);
            
            if (hasImageBlock) {
                await discordUtils.safeDelete(message);
                await discordUtils.safeDM(message.author, { content: 'Your message was deleted because you currently have an active image restriction.' });
                return;
            }
        }

        // 2. Automod
        const blockedWords = db.prepare('SELECT * FROM blocked_words').all();
        const contentLower = message.content.toLowerCase();
        
        for (const blocked of blockedWords) {
            if (contentLower.includes(blocked.word)) {
                await discordUtils.safeDelete(message);
                
                // Flagged by automod, create a report
                const reportId = ids.generateId();
                db.prepare(`
                    INSERT INTO reports 
                    (id, reporter_id, reporter_username, reported_user_id, reported_username, message_id, channel_id, message_content, reason, policy, detection_source, status, automod_confident, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `).run(
                    reportId, client.user.id, 'AUTOMOD', userId, message.author.username, message.id, message.channel.id, message.content, 
                    `Triggered blocked word: ||${blocked.word}||`, blocked.policy, config.DETECTION_SOURCES.AUTOMATED_DETECTION, config.REPORT_STATUS.PENDING, 1, now
                );

                // Notify mod channel
                const modChannel = message.guild.channels.cache.get(config.MODERATION_CHANNEL_ID);
                if (modChannel) {
                    modChannel.send(`Automod flagged message from ${message.author.tag}. Report ID: ${reportId}`);
                }

                await discordUtils.safeDM(message.author, { content: 'Your message was removed by automod and reported to staff for review.' });
                break;
            }
        }
    }
};
