const db = require('../database/index.js');
const config = require('../config.js');
const timeUtils = require('../utils/time.js');

module.exports = {
    name: 'messageReactionAdd',
    async execute(reaction, user) {
        if (user.bot) return;

        const now = timeUtils.now();
        const hasReactionBlock = db.prepare('SELECT id FROM restrictions WHERE user_id = ? AND type = ? AND active = 1 AND expires_at > ?')
            .get(user.id, config.RESTRICTION_TYPES.REACTION_BLOCK, now);
        
        if (hasReactionBlock) {
            try {
                await reaction.users.remove(user.id);
            } catch (err) {
                console.error('Failed to remove reaction:', err);
            }
        }
    }
};
