const db = require('../database/index.js');
const timeUtils = require('../utils/time.js');
const discordUtils = require('../utils/discord.js');
const config = require('../config.js');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(`Ready! Logged in as ${client.user.tag}`);

        const checkExpiredRestrictions = async () => {
            const now = timeUtils.now();
            const expired = db.prepare('SELECT * FROM restrictions WHERE active = 1 AND expires_at <= ?').all(now);

            for (const restriction of expired) {
                // Deactivate in DB
                db.prepare('UPDATE restrictions SET active = 0 WHERE id = ?').run(restriction.id);
                console.log(`Restriction ${restriction.id} (Type: ${restriction.type}) expired for user ${restriction.user_id}`);
                
                // If it's a timeout, try to un-timeout
                if (restriction.type === config.RESTRICTION_TYPES.TIMEOUT) {
                    try {
                        const guild = await client.guilds.fetch(config.GUILD_ID);
                        const member = await guild.members.fetch(restriction.user_id).catch(() => null);
                        if (member) {
                            await member.timeout(null, 'Timeout restriction expired');
                        }
                    } catch (err) {
                        console.error('Failed to lift timeout:', err);
                    }
                }
            }
        };

        // Run immediately
        await checkExpiredRestrictions();

        // Run every 5 minutes
        setInterval(checkExpiredRestrictions, 5 * 60 * 1000);
    }
};
