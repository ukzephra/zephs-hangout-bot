const errors = require('../utils/errors.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        const client = interaction.client;
        
        try {
            if (interaction.isChatInputCommand()) {
                const command = client.commands.get(interaction.commandName);
                if (!command) return;
                await command.execute(interaction);
            } else if (interaction.isMessageContextMenuCommand() || interaction.isUserContextMenuCommand()) {
                const command = client.commands.get(interaction.commandName);
                if (!command) return;
                await command.execute(interaction);
            } else if (interaction.isButton()) {
                // Handle button logic (can route to separate handlers later)
                const customId = interaction.customId;
                if (customId.startsWith('report:')) {
                    // require('../handlers/reports.js').handleButton(interaction)
                } else if (customId.startsWith('appeal:')) {
                    // require('../handlers/appeals.js').handleButton(interaction)
                }
                // If unhandled here, avoid throwing if we plan to implement later
                if (!interaction.replied && !interaction.deferred) {
                    await interaction.reply({ content: 'Button acknowledged.', ephemeral: true });
                }
            } else if (interaction.isModalSubmit()) {
                const customId = interaction.customId;
                // Handle modals
                if (customId.startsWith('report_msg_modal:') || customId.startsWith('report_usr_modal:')) {
                    await interaction.reply({ content: 'Report received.', ephemeral: true });
                }
            }
        } catch (error) {
            console.error('Error handling interaction:', error);
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: 'There was an error while executing this interaction!', ephemeral: true }).catch(() => {});
            } else {
                await interaction.reply({ content: 'There was an error while executing this interaction!', ephemeral: true }).catch(() => {});
            }
        }
    }
};
