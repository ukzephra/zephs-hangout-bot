const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    data: { name: 'Report Message', type: 3 }, // ApplicationCommandType.Message = 3
    async execute(interaction) {
        const message = interaction.targetMessage;
        
        const modal = new ModalBuilder()
            .setCustomId(`report_msg_modal:${message.id}`)
            .setTitle('Report Message');

        const reasonInput = new TextInputBuilder()
            .setCustomId('reason')
            .setLabel('Reason for reporting')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(1000);

        const row = new ActionRowBuilder().addComponents(reasonInput);
        modal.addComponents(row);

        await interaction.showModal(modal);
    }
};
