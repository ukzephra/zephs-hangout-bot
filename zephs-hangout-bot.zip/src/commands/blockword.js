const { MessageFlags } = require('discord.js');
const db = require('../database/index.js');
const { requireStaff } = require('../permissions/index.js');
const ids = require('../utils/ids.js');
const timeUtils = require('../utils/time.js');

module.exports = {
    data: { name: 'blockword' },
    async execute(interaction) {
        if (!requireStaff(interaction.member)) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'add') {
            const word = interaction.options.getString('word').toLowerCase();
            const policy = interaction.options.getString('policy');
            const severity = interaction.options.getString('severity');

            try {
                db.prepare('INSERT INTO blocked_words (id, word, policy, severity, added_by, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
                    ids.generateId(), word, policy, severity, interaction.user.id, timeUtils.now()
                );
                await interaction.reply({ content: `Added \`${word}\` to blocked words (Policy: ${policy}, Severity: ${severity}).`, ephemeral: true });
            } catch (err) {
                if (err.message.includes('UNIQUE constraint failed')) {
                    await interaction.reply({ content: `The word \`${word}\` is already blocked.`, ephemeral: true });
                } else {
                    console.error(err);
                    await interaction.reply({ content: 'An error occurred.', ephemeral: true });
                }
            }
        } else if (subcommand === 'remove') {
            const word = interaction.options.getString('word').toLowerCase();
            const info = db.prepare('DELETE FROM blocked_words WHERE word = ?').run(word);
            if (info.changes > 0) {
                await interaction.reply({ content: `Removed \`${word}\` from blocked words.`, ephemeral: true });
            } else {
                await interaction.reply({ content: `The word \`${word}\` was not found.`, ephemeral: true });
            }
        } else if (subcommand === 'list') {
            const words = db.prepare('SELECT * FROM blocked_words').all();
            if (words.length === 0) {
                return interaction.reply({ content: 'No blocked words found.', ephemeral: true });
            }
            const list = words.map(w => `- \`${w.word}\` (${w.severity}) -> ${w.policy}`).join('\n');
            await interaction.reply({ content: `**Blocked Words:**\n${list}`, ephemeral: true });
        }
    }
};
