const { MessageFlags } = require('discord.js');
const { requireStaff } = require('../permissions/index.js');
const discordUtils = require('../utils/discord.js');
const config = require('../config.js');

module.exports = {
    data: { name: 'staffmessage' },
    async execute(interaction) {
        if (!requireStaff(interaction.member)) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        const subject = interaction.options.getString('subject');
        const content = interaction.options.getString('content');
        const channel = interaction.options.getChannel('channel') || interaction.channel;
        const user = interaction.options.getUser('user');
        const author = interaction.options.getString('author') || 'SYSTEM';
        const replyTo = interaction.options.getString('reply_to');
        const includeForm = interaction.options.getBoolean('include_form');

        const components = [];
        components.push({
            type: 17,
            components: [
                { type: 10, text: `**${config.EMOJIS.STAFF} OFFICIAL MESSAGE: ${subject}**`, style: 1 },
                { type: 10, text: `Author: ${author}`, style: 2 }
            ]
        });
        components.push({ type: 14 }); // Separator
        components.push({
            type: 17,
            components: [
                { type: 10, text: content, style: 1 }
            ]
        });

        if (includeForm) {
            components.push({
                type: 1, // ActionRow
                components: [
                    { type: 2, style: 1, label: 'Contact Staff', custom_id: 'staffmsg:form:new' }
                ]
            });
        }

        const payload = {
            content: '',
            components: components,
            flags: [MessageFlags.IsComponentsV2]
        };

        if (replyTo) {
            payload.reply = { messageReference: replyTo, failIfNotExists: false };
        }

        try {
            if (user) {
                await discordUtils.safeDM(user, payload);
                await interaction.reply({ content: `Sent DM to ${user.tag}.`, ephemeral: true });
            } else {
                await channel.send(payload);
                await interaction.reply({ content: `Message sent to ${channel.name}.`, ephemeral: true });
            }
        } catch (error) {
            console.error('Failed to send staff message', error);
            await interaction.reply({ content: 'Failed to send message. Check permissions or user DM settings.', ephemeral: true });
        }
    }
};
