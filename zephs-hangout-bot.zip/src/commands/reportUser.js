const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    data: { name: 'Report User', type: 2 }, // ApplicationCommandType.User = 2
    async execute(interaction) {
        const user = interaction.targetUser;
        
        const modal = new ModalBuilder()
            .setCustomId(`report_usr_modal:${user.id}`)
            .setTitle(`Report User: ${user.username}`);

        const reasonInput = new TextInputBuilder()
            .setCustomId('reason')
            .setLabel('Reason for reporting')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(1000);

        const row = new ActionRowBuilder().addComponents(reasonInput);
        modal.addComponents(row);

        await interaction.showModal(modal);
    }
};
