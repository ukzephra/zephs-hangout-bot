const { MessageFlags } = require('discord.js');
const db = require('../database/index.js');
const config = require('../config.js');
const timeUtils = require('../utils/time.js');
const errors = require('../utils/errors.js');

module.exports = {
    data: { name: 'mystanding' },
    async execute(interaction) {
        await errors.safeDefer(interaction, true);
        
        const userId = interaction.user.id;
        let user = db.prepare('SELECT * FROM users WHERE user_id = ?').get(userId);
        if (!user) {
            user = { user_id: userId, standing: config.STANDINGS.WARNING_STAGE };
        }

        const activeViolations = db.prepare(`SELECT * FROM violations WHERE user_id = ? AND active = 1`).all(userId);
        let currentStanding = config.STANDINGS.WARNING_STAGE;
        const count = activeViolations.length;
        if (count >= config.THRESHOLDS.SUSPENDED) currentStanding = config.STANDINGS.SUSPENDED;
        else if (count >= config.THRESHOLDS.AT_RISK) currentStanding = config.STANDINGS.AT_RISK;
        else if (count >= config.THRESHOLDS.VERY_LIMITED) currentStanding = config.STANDINGS.VERY_LIMITED;
        else if (count >= config.THRESHOLDS.LIMITED) currentStanding = config.STANDINGS.LIMITED;

        let emoji = config.EMOJIS.WARNING;
        if (currentStanding === config.STANDINGS.LIMITED) emoji = config.EMOJIS.LIMITED;
        else if (currentStanding === config.STANDINGS.VERY_LIMITED || currentStanding === config.STANDINGS.AT_RISK) emoji = config.EMOJIS.VERY_LIMITED;
        else if (currentStanding === config.STANDINGS.SUSPENDED) emoji = config.EMOJIS.SUSPENDED;

        const restrictions = db.prepare(`SELECT * FROM restrictions WHERE user_id = ? AND active = 1 AND expires_at > ?`).all(userId, Date.now());

        const components = [];
        components.push({
            type: 17, // Container
            components: [
                { type: 10, text: `${emoji} **Account Standing:** ${config.STANDING_LABELS[currentStanding]}`, style: 1 },
                { type: 10, text: `Active Violations: **${count}**`, style: 2 }
            ]
        });

        if (restrictions.length > 0) {
            const resComps = restrictions.map(r => {
                return { type: 10, text: `- **${r.type}**: Expires ${timeUtils.discordRelative(r.expires_at)}`, style: 2 };
            });
            components.push({
                type: 17,
                components: [
                    { type: 10, text: `**Active Restrictions**`, style: 1 },
                    ...resComps
                ]
            });
        }

        components.push({
            type: 1, // ActionRow
            components: [
                { type: 2, style: 5, label: 'View Server Rules', url: `https://discord.com/channels/${config.GUILD_ID}/${config.RULES_CHANNEL_ID}` }
            ]
        });

        await interaction.editReply({
            content: '',
            components: components,
            flags: [MessageFlags.IsComponentsV2, MessageFlags.Ephemeral]
        });
    }
};
