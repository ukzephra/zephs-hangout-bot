const { REST, Routes, SlashCommandBuilder, ContextMenuCommandBuilder, ApplicationCommandType } = require('discord.js');
const config = require('../config.js');
require('dotenv').config();

const commands = [
    new SlashCommandBuilder()
        .setName('mystanding')
        .setDescription('Check your current account standing and active restrictions.'),
    
    new SlashCommandBuilder()
        .setName('blockword')
        .setDescription('Manage blocked words for automod.')
        .addSubcommand(subcmd => subcmd.setName('add')
            .setDescription('Add a blocked word')
            .addStringOption(opt => opt.setName('word').setDescription('The word to block').setRequired(true))
            .addStringOption(opt => opt.setName('policy').setDescription('Associated policy').setRequired(true).addChoices(...config.POLICY_CHOICES))
            .addStringOption(opt => opt.setName('severity').setDescription('Severity: WARNING or VIOLATION').setRequired(true).addChoices(
                { name: 'WARNING', value: 'WARNING' },
                { name: 'VIOLATION', value: 'VIOLATION' }
            ))
        )
        .addSubcommand(subcmd => subcmd.setName('remove')
            .setDescription('Remove a blocked word')
            .addStringOption(opt => opt.setName('word').setDescription('The word to remove').setRequired(true))
        )
        .addSubcommand(subcmd => subcmd.setName('list')
            .setDescription('List all blocked words')
        ),
    
    new SlashCommandBuilder()
        .setName('staffmessage')
        .setDescription('Send an official staff message.')
        .addStringOption(opt => opt.setName('subject').setDescription('Subject of the message').setRequired(true))
        .addStringOption(opt => opt.setName('content').setDescription('Content of the message').setRequired(true))
        .addChannelOption(opt => opt.setName('channel').setDescription('Target channel (leave blank for current)').setRequired(false))
        .addUserOption(opt => opt.setName('user').setDescription('Target user (DMs them instead of channel)').setRequired(false))
        .addStringOption(opt => opt.setName('author').setDescription('Author name (defaults to SYSTEM)').setRequired(false))
        .addStringOption(opt => opt.setName('reply_to').setDescription('Message ID to reply to').setRequired(false))
        .addBooleanOption(opt => opt.setName('include_form').setDescription('Include a contact staff button').setRequired(false)),
    
    new ContextMenuCommandBuilder()
        .setName('Report Message')
        .setType(ApplicationCommandType.Message),

    new ContextMenuCommandBuilder()
        .setName('Report User')
        .setType(ApplicationCommandType.User)
].map(command => command.toJSON());

async function deployCommands() {
    const token = process.env.DISCORD_BOT_TOKEN;
    if (!token) {
        console.error('No DISCORD_BOT_TOKEN found in environment!');
        return;
    }
    
    // Extract client ID from token (first part before the first dot, decoded from base64)
    const clientId = Buffer.from(token.split('.')[0], 'base64').toString('utf-8');
    
    const rest = new REST({ version: '10' }).setToken(token);
    try {
        console.log(`Started refreshing commands for Guild: ${config.GUILD_ID}, Client ID: ${clientId}`);
        await rest.put(
            Routes.applicationGuildCommands(clientId, config.GUILD_ID),
            { body: commands },
        );
        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error('Error deploying commands:', error);
    }
}

// Allow script execution directly via node src/commands/deploy.js
if (require.main === module) {
    deployCommands();
}

module.exports = { deployCommands };
