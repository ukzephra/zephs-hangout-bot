const usersDB = require('../database/users');
const violationsDB = require('../database/violations');
const restrictionsDB = require('../database/restrictions');
const config = require('../config');

/**
 * Calculate standing based on active violation count.
 * @param {string} userId - The user's Discord ID
 * @returns {string} The appropriate standing
 */
function calculateStanding(userId) {
    const activeViolations = violationsDB.getActiveViolations(userId);
    const count = activeViolations.length;

    if (count >= config.THRESHOLDS.SUSPENDED) {
        return config.STANDINGS.SUSPENDED;
    } else if (count >= config.THRESHOLDS.AT_RISK) {
        return config.STANDINGS.AT_RISK;
    } else if (count >= config.THRESHOLDS.VERY_LIMITED) {
        return config.STANDINGS.VERY_LIMITED;
    } else if (count >= config.THRESHOLDS.LIMITED) {
        return config.STANDINGS.LIMITED;
    } else {
        return config.STANDINGS.WARNING_STAGE;
    }
}

/**
 * Get full standing info for a user.
 * @param {string} userId - The user's Discord ID
 * @returns {Object} Standing info including active count, violations, restrictions
 */
function getStandingInfo(userId) {
    const user = usersDB.getUser(userId);
    const activeViolations = violationsDB.getActiveViolations(userId);
    const activeCount = activeViolations.length;
    
    let standing = config.STANDINGS.WARNING_STAGE;
    if (user && user.standing) {
        standing = user.standing;
    } else {
        standing = calculateStanding(userId);
    }

    const restrictions = restrictionsDB.getActiveRestrictions(userId);

    return {
        standing,
        activeCount,
        violations: activeViolations,
        restrictions
    };
}

/**
 * Recalculate standing, update user record, return changes.
 * @param {string} userId - The user's Discord ID
 * @returns {Object} { previousStanding, newStanding, changed }
 */
function recalculateAndUpdate(userId) {
    const user = usersDB.getUser(userId) || usersDB.createUser(userId, 'Unknown'); // username can be updated later
    const previousStanding = user.standing;
    const newStanding = calculateStanding(userId);

    const changed = previousStanding !== newStanding;

    if (changed) {
        usersDB.updateStanding(userId, newStanding);
    }

    return {
        previousStanding,
        newStanding,
        changed
    };
}

/**
 * Preview what standing would be after adding one more violation.
 * @param {string} userId - The user's Discord ID
 * @returns {string} The resulting standing
 */
function getStandingAfterNewViolation(userId) {
    const activeViolations = violationsDB.getActiveViolations(userId);
    const count = activeViolations.length + 1; // +1 for the theoretical new violation

    if (count >= config.THRESHOLDS.SUSPENDED) {
        return config.STANDINGS.SUSPENDED;
    } else if (count >= config.THRESHOLDS.AT_RISK) {
        return config.STANDINGS.AT_RISK;
    } else if (count >= config.THRESHOLDS.VERY_LIMITED) {
        return config.STANDINGS.VERY_LIMITED;
    } else if (count >= config.THRESHOLDS.LIMITED) {
        return config.STANDINGS.LIMITED;
    } else {
        return config.STANDINGS.WARNING_STAGE;
    }
}

module.exports = {
    calculateStanding,
    getStandingInfo,
    recalculateAndUpdate,
    getStandingAfterNewViolation
};
