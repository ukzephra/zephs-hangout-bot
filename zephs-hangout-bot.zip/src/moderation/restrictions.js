const restrictionsDB = require('../database/restrictions');
const config = require('../config');
const { safeTimeout, safeFetchMember } = require('../utils/discord');

const scheduledTimeouts = new Map();

/**
 * Check if user has an active restriction of given type.
 * @param {string} userId - The user's Discord ID
 * @param {string} type - Restriction type
 * @returns {boolean}
 */
function hasActiveRestriction(userId, type) {
    const active = restrictionsDB.getActiveRestrictions(userId);
    return active.some(r => r.type === type && new Date(r.expires_at) > new Date());
}

/**
 * Handle a single restriction expiry
 * @param {Object} client - Discord client
 * @param {Object} restriction - Restriction record
 */
async function processExpiredRestriction(client, restriction) {
    restrictionsDB.deactivateRestriction(restriction.id);
    console.log(`[Restrictions] Expired restriction ${restriction.id} of type ${restriction.type} for user ${restriction.user_id}`);

    if (restriction.type === config.RESTRICTION_TYPES.TIMEOUT) {
        // If they have no other active timeouts, remove the discord timeout
        const remainingTimeouts = restrictionsDB.getActiveRestrictions(restriction.user_id)
            .filter(r => r.type === config.RESTRICTION_TYPES.TIMEOUT);
            
        if (remainingTimeouts.length === 0) {
            const guild = client.guilds.cache.get(config.GUILD_ID);
            if (guild) {
                const member = await safeFetchMember(guild, restriction.user_id);
                if (member && member.isCommunicationDisabled()) {
                    await safeTimeout(member, null, 'Timeout restriction expired');
                }
            }
        }
    }
}

/**
 * Schedule a timeout for a restriction's expiry.
 * @param {Object} client - Discord client
 * @param {Object} restriction - Restriction record
 */
function scheduleExpiry(client, restriction) {
    if (scheduledTimeouts.has(restriction.id)) {
        clearTimeout(scheduledTimeouts.get(restriction.id));
    }

    const expiresAt = new Date(restriction.expires_at).getTime();
    const now = Date.now();
    const delay = expiresAt - now;

    if (delay <= 0) {
        processExpiredRestriction(client, restriction);
    } else {
        // Maximum delay for setTimeout is 2147483647 ms (~24.8 days)
        const maxDelay = 2147483647;
        if (delay > maxDelay) {
            const timeout = setTimeout(() => {
                scheduleExpiry(client, restriction);
            }, maxDelay);
            scheduledTimeouts.set(restriction.id, timeout);
        } else {
            const timeout = setTimeout(() => {
                processExpiredRestriction(client, restriction);
                scheduledTimeouts.delete(restriction.id);
            }, delay);
            scheduledTimeouts.set(restriction.id, timeout);
        }
    }
}

/**
 * Periodic check (backup) to find all expired active restrictions.
 * @param {Object} client - Discord client
 */
function checkAndExpireRestrictions(client) {
    const expired = restrictionsDB.getExpiredActiveRestrictions();
    for (const restriction of expired) {
        processExpiredRestriction(client, restriction);
        if (scheduledTimeouts.has(restriction.id)) {
            clearTimeout(scheduledTimeouts.get(restriction.id));
            scheduledTimeouts.delete(restriction.id);
        }
    }
}

/**
 * Load all active restrictions and schedule/expire them.
 * @param {Object} client - Discord client
 */
function initRestrictions(client) {
    console.log('[Restrictions] Initializing restriction schedules...');
    
    // First run the backup check to catch any that expired while bot was offline
    checkAndExpireRestrictions(client);

    // Schedule remaining active ones
    const active = restrictionsDB.getAllActiveRestrictions();
    for (const restriction of active) {
        scheduleExpiry(client, restriction);
    }

    // Set interval for backup checks every 5 minutes
    setInterval(() => {
        checkAndExpireRestrictions(client);
    }, 5 * 60 * 1000);
}

module.exports = {
    initRestrictions,
    scheduleExpiry,
    checkAndExpireRestrictions,
    hasActiveRestriction,
    processExpiredRestriction
};
