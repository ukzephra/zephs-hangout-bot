const config = require('../config');
const { safeTimeout, safeBan, safeUnban, safeFetchMember } = require('../utils/discord');
const restrictionsDB = require('../database/restrictions');
const { generateId } = require('../utils/ids');
const { fromNow } = require('../utils/time');

/**
 * Apply Discord punishments based on standing transitions.
 * @param {Object} client - Discord client
 * @param {string} guildId - Discord Guild ID
 * @param {string} userId - Target User ID
 * @param {string} previousStanding - User's old standing
 * @param {string} newStanding - User's new standing
 * @param {string} violationId - ID of the violation that triggered this
 * @returns {Promise<Object>} Resulting punishments and restrictions applied
 */
async function applyPunishment(client, guildId, userId, previousStanding, newStanding, violationId) {
    const punishments = [];
    const newRestrictions = [];

    const guild = client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId).catch(() => null);
    if (!guild) return { punishments, restrictions: newRestrictions };

    const member = await safeFetchMember(guild, userId);

    if (newStanding === config.STANDINGS.LIMITED) {
        // Timeout 2 days + Image block 4 days
        const timeoutDuration = 2 * 24 * 60 * 60 * 1000;
        const imageBlockDuration = 4 * 24 * 60 * 60 * 1000;
        
        if (member) {
            await applyTimeout(member, timeoutDuration, `Reached LIMITED standing (Violation ${violationId})`);
            punishments.push('Timeout applied for 2 days');
        }

        const timeoutRes = restrictionsDB.createRestriction(userId, config.RESTRICTION_TYPES.TIMEOUT, violationId, fromNow(timeoutDuration));
        const imageRes = restrictionsDB.createRestriction(userId, config.RESTRICTION_TYPES.IMAGE_BLOCK, violationId, fromNow(imageBlockDuration));
        newRestrictions.push(timeoutRes, imageRes);
        punishments.push('Image block applied for 4 days');

    } else if (newStanding === config.STANDINGS.VERY_LIMITED) {
        // Timeout 5 days + Image/Voice/Reaction block 21 days
        const timeoutDuration = 5 * 24 * 60 * 60 * 1000;
        const otherDuration = 21 * 24 * 60 * 60 * 1000;

        if (member) {
            await applyTimeout(member, timeoutDuration, `Reached VERY_LIMITED standing (Violation ${violationId})`);
            punishments.push('Timeout applied for 5 days');
        }

        const timeoutRes = restrictionsDB.createRestriction(userId, config.RESTRICTION_TYPES.TIMEOUT, violationId, fromNow(timeoutDuration));
        const imageRes = restrictionsDB.createRestriction(userId, config.RESTRICTION_TYPES.IMAGE_BLOCK, violationId, fromNow(otherDuration));
        const voiceRes = restrictionsDB.createRestriction(userId, config.RESTRICTION_TYPES.VOICE_BLOCK, violationId, fromNow(otherDuration));
        const reactionRes = restrictionsDB.createRestriction(userId, config.RESTRICTION_TYPES.REACTION_BLOCK, violationId, fromNow(otherDuration));
        
        newRestrictions.push(timeoutRes, imageRes, voiceRes, reactionRes);
        punishments.push('Image, Voice, and Reaction block applied for 21 days');

    } else if (newStanding === config.STANDINGS.SUSPENDED) {
        // Ban the user
        await applyBan(guild, userId, `Reached SUSPENDED standing (Violation ${violationId})`);
        punishments.push('User permanently banned');
    }

    return { punishments, restrictions: newRestrictions };
}

/**
 * Remove restrictions linked to a specific violation (for appeal reversal).
 * @param {Object} client - Discord client
 * @param {string} guildId - Discord Guild ID
 * @param {string} userId - Target User ID
 * @param {string} violationId - ID of the reversed violation
 */
async function removePunishments(client, guildId, userId, violationId) {
    const userRestrictions = restrictionsDB.getActiveRestrictions(userId);
    const targetRestrictions = userRestrictions.filter(r => r.violation_id === violationId);
    
    for (const restriction of targetRestrictions) {
        restrictionsDB.deactivateRestriction(restriction.id);
    }

    // Check if there are any remaining active timeout restrictions
    const remainingTimeouts = restrictionsDB.getActiveRestrictions(userId)
        .filter(r => r.type === config.RESTRICTION_TYPES.TIMEOUT);

    if (remainingTimeouts.length === 0) {
        const guild = client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId).catch(() => null);
        if (guild) {
            const member = await safeFetchMember(guild, userId);
            if (member && member.isCommunicationDisabled()) {
                await applyTimeout(member, null, `Timeout removed due to reversed violation ${violationId}`);
            }
        }
    }
}

async function applyTimeout(member, durationMs, reason) {
    return safeTimeout(member, durationMs, reason);
}

async function applyBan(guild, userId, reason) {
    return safeBan(guild, userId, reason);
}

async function removeBan(guild, userId, reason) {
    return safeUnban(guild, userId, reason);
}

module.exports = {
    applyPunishment,
    removePunishments,
    applyTimeout,
    applyBan,
    removeBan
};
