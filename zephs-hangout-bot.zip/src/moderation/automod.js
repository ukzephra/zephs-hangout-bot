const blockedWordsDB = require('../database/blockedWords');
const config = require('../config');

// Try requiring openai gracefully
let OpenAI;
try {
    OpenAI = require('openai').OpenAI;
} catch (e) {
    OpenAI = null;
}

const openai = OpenAI && process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

// Simple in-memory message cache (Map<userId, {content, timestamp}[]>)
const messageCache = new Map();

/**
 * Determine if automod should auto-punish vs send for review
 * @param {string} confidence - HIGH, MEDIUM, LOW
 * @param {string} userId - User ID
 * @param {boolean} isViolationSeverity - Blocked word has VIOLATION severity
 * @returns {Object} { autoAction: boolean, reason: string }
 */
function shouldAutoAction(confidence, userId, isViolationSeverity = false) {
    if (confidence === 'HIGH' && isViolationSeverity) {
        return { autoAction: true, reason: 'High confidence match with a strict violation rule.' };
    }
    return { autoAction: false, reason: 'Requires moderator review.' };
}

/**
 * Detect spam patterns
 * @param {Object} message - discord.js Message object
 * @param {Array} recentMessages - Array of user's recent messages
 * @returns {Object} { flagged, details }
 */
function checkSpamPatterns(message, recentMessages) {
    const now = Date.now();
    
    // 5+ messages in 5 seconds
    const in5s = recentMessages.filter(m => now - m.timestamp < 5000);
    if (in5s.length >= 5) {
        return { flagged: true, details: 'Sent 5+ messages in 5 seconds' };
    }

    // Same content 3+ times in 30 seconds
    const in30s = recentMessages.filter(m => now - m.timestamp < 30000 && m.content === message.content);
    if (in30s.length >= 3) {
        return { flagged: true, details: 'Sent same message 3+ times in 30 seconds' };
    }

    return { flagged: false, details: null };
}

/**
 * Call OpenAI Moderation API endpoint
 * @param {string} content - Message content
 * @returns {Promise<Object>} { flagged, categories, policy, confidence }
 */
async function checkWithOpenAI(content) {
    if (!openai) return { flagged: false, categories: [], policy: null, confidence: 'LOW' };

    try {
        const response = await openai.moderations.create({ input: content });
        const result = response.results[0];

        if (!result.flagged) {
            return { flagged: false, categories: [], policy: null, confidence: 'LOW' };
        }

        const flaggedCategories = Object.keys(result.categories).filter(c => result.categories[c]);
        
        // Map OpenAI categories to our policies
        let policy = config.POLICIES.DISCORD_TOS;
        if (flaggedCategories.includes('sexual') || flaggedCategories.includes('sexual/minors')) {
            policy = config.POLICIES.SEXUAL_CONTENT;
        } else if (flaggedCategories.includes('harassment') || flaggedCategories.includes('harassment/threatening')) {
            policy = config.POLICIES.BULLYING_HARASSMENT;
        } else if (flaggedCategories.includes('hate') || flaggedCategories.includes('hate/threatening')) {
            policy = config.POLICIES.EXTREME_LANGUAGE;
        } else if (flaggedCategories.includes('violence') || flaggedCategories.includes('violence/graphic')) {
            policy = config.POLICIES.THREATS;
        }

        return {
            flagged: true,
            categories: flaggedCategories,
            policy: policy,
            confidence: 'MEDIUM' // Automod using AI is mostly medium confidence
        };
    } catch (error) {
        console.error('[AutoMod] OpenAI API error:', error);
        return { flagged: false, categories: [], policy: null, confidence: 'LOW' };
    }
}

/**
 * Main entry point for automod check
 * @param {Object} message - discord.js Message object
 * @returns {Promise<Object>} Results of the check
 */
async function checkMessage(message) {
    const content = message.content;
    const userId = message.author.id;
    const now = Date.now();

    // 1. Check Spam Patterns
    let userMessages = messageCache.get(userId) || [];
    // Clean up old entries
    userMessages = userMessages.filter(m => now - m.timestamp < 60000);
    userMessages.push({ content, timestamp: now });
    messageCache.set(userId, userMessages);

    const spamCheck = checkSpamPatterns(message, userMessages);
    if (spamCheck.flagged) {
        return {
            flagged: true,
            matches: [],
            source: 'SPAM',
            policy: config.POLICIES.SPAM,
            confidence: 'HIGH',
            details: spamCheck.details,
            isViolationSeverity: true
        };
    }

    // 2. Check Blocked Words
    if (blockedWordsDB.checkMessage) {
        const blockedWordMatch = blockedWordsDB.checkMessage(content);
        if (blockedWordMatch && blockedWordMatch.flagged) {
            return {
                flagged: true,
                matches: [blockedWordMatch.word],
                source: 'BLOCKED_WORD',
                policy: blockedWordMatch.policy,
                confidence: 'HIGH',
                details: `Matched blocked word: ${blockedWordMatch.word}`,
                isViolationSeverity: blockedWordMatch.severity === 'VIOLATION'
            };
        }
    }

    // 3. Check with OpenAI
    const openAICheck = await checkWithOpenAI(content);
    if (openAICheck.flagged) {
        return {
            flagged: true,
            matches: openAICheck.categories,
            source: 'OPENAI',
            policy: openAICheck.policy,
            confidence: openAICheck.confidence,
            details: `OpenAI Flagged: ${openAICheck.categories.join(', ')}`,
            isViolationSeverity: false
        };
    }

    return { flagged: false };
}

module.exports = {
    checkMessage,
    checkWithOpenAI,
    checkSpamPatterns,
    shouldAutoAction
};
